# this is drawMolecule.py
OpenDatabase("~/teaching/visitWorkshop/datasets/molecules/1l5q.pdb", 0)
AddPlot("Molecule", "element", 1, 1)
DrawPlots()

MoleculeAtts = MoleculeAttributes()

MoleculeAtts.drawAtomsAs = MoleculeAtts.SphereAtoms # NoAtoms,SphereAtoms,ImposterAtoms
MoleculeAtts.scaleRadiusBy = MoleculeAtts.Fixed  # Fixed,Covalent,Atomic,Variable
MoleculeAtts.atomSphereQuality = MoleculeAtts.Medium  # Low, Medium, High, Super
MoleculeAtts.radiusFixed = 0.5

MoleculeAtts.drawBondsAs = MoleculeAtts.CylinderBonds # NoBonds,LineBonds,CylinderBonds
MoleculeAtts.colorBonds = MoleculeAtts.ColorByAtom  # ColorByAtom, SingleColor
MoleculeAtts.bondCylinderQuality = MoleculeAtts.Medium  # Low, Medium, High, Super
MoleculeAtts.bondRadius = 0.08

MoleculeAtts.elementColorTable = "cpk_jmol"
MoleculeAtts.legendFlag = 1
SetPlotOptions(MoleculeAtts)
