# this is terrain3d.py
DeleteAllPlots()
OpenDatabase("~/teaching/visitWorkshop/datasets/092g06_0100_deme.dem")
AddPlot("Pseudocolor", "height")

AddOperator("Elevate")
elAtts = ElevateAttributes()
elAtts.useXYLimits = 1      # if X/Y are longitude/latitude, z-height would be off
SetOperatorOptions(elAtts)   #     => simply rescale all 3 axes to a cube

AddOperator("Transform")
trAtts = TransformAttributes()
trAtts.doScale = 1     # turn on scaling
trAtts.scaleX = 1
trAtts.scaleY = 1
trAtts.scaleZ = 0.05   # and make z-heights smaller
SetOperatorOptions(trAtts)

DrawPlots()
