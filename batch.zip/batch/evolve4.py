from paraview.simple import *

icecmonmeannc = NetCDFReader(FileName=['/Users/razoumov/Movies/data/surfaceIce/icec.mon.mean.nc'])

animationScene1 = GetAnimationScene()
# animationScene1.StartTime = -14824
# animationScene1.EndTime = -14794
animationScene1.UpdateAnimationUsingDataTimeSteps()

icecmonmeannc.Dimensions = '(lat, lon)'
icecmonmeannc.SphericalCoordinates = 1
icecmonmeannc.VerticalScale = 1.0
icecmonmeannc.VerticalBias = 0.0
icecmonmeannc.ReplaceFillValueWithNan = 0
icecmonmeannc.OutputType = 'Automatic'

renderView1 = GetActiveViewOrCreate('RenderView')
renderView1.ViewSize = [1246, 882]

threshold1 = Threshold(Input=icecmonmeannc)
threshold1.Scalars = ['CELLS', 'icec']
threshold1.ThresholdRange = [0.0, 1.e20]
threshold1.AllScalars = 1
threshold1.UseContinuousCellRange = 0
threshold1.ThresholdRange = [0.0, 100.0]

threshold1Display = Show(threshold1, renderView1)
threshold1Display.Representation = 'Surface'
threshold1Display.AmbientColor = [1.0, 1.0, 1.0]
threshold1Display.ColorArrayName = [None, '']
threshold1Display.DiffuseColor = [1.0, 1.0, 1.0]
threshold1Display.LookupTable = None
threshold1Display.MapScalars = 1
threshold1Display.InterpolateScalarsBeforeMapping = 1
threshold1Display.Opacity = 1.0
threshold1Display.PointSize = 2.0
threshold1Display.LineWidth = 1.0
threshold1Display.Interpolation = 'Gouraud'
threshold1Display.Specular = 0.0
threshold1Display.SpecularColor = [1.0, 1.0, 1.0]
threshold1Display.SpecularPower = 100.0
threshold1Display.Ambient = 0.0
threshold1Display.Diffuse = 1.0
threshold1Display.EdgeColor = [0.0, 0.0, 0.5]
threshold1Display.BackfaceRepresentation = 'Follow Frontface'
threshold1Display.BackfaceAmbientColor = [1.0, 1.0, 1.0]
threshold1Display.BackfaceDiffuseColor = [1.0, 1.0, 1.0]
threshold1Display.BackfaceOpacity = 1.0
threshold1Display.Position = [0.0, 0.0, 0.0]
threshold1Display.Scale = [1.0, 1.0, 1.0]
threshold1Display.Orientation = [0.0, 0.0, 0.0]
threshold1Display.Origin = [0.0, 0.0, 0.0]
threshold1Display.Pickable = 1
threshold1Display.Texture = None
threshold1Display.Triangulate = 0
threshold1Display.NonlinearSubdivisionLevel = 1
threshold1Display.CubeAxesColor = [1.0, 1.0, 1.0]
threshold1Display.CubeAxesCornerOffset = 0.0
threshold1Display.CubeAxesFlyMode = 'Closest Triad'
threshold1Display.CubeAxesInertia = 1
threshold1Display.CubeAxesTickLocation = 'Inside'
threshold1Display.CubeAxesXAxisMinorTickVisibility = 1
threshold1Display.CubeAxesXAxisTickVisibility = 1
threshold1Display.CubeAxesXAxisVisibility = 1
threshold1Display.CubeAxesXGridLines = 0
threshold1Display.CubeAxesXTitle = 'X-Axis'
threshold1Display.CubeAxesUseDefaultXTitle = 1
threshold1Display.CubeAxesYAxisMinorTickVisibility = 1
threshold1Display.CubeAxesYAxisTickVisibility = 1
threshold1Display.CubeAxesYAxisVisibility = 1
threshold1Display.CubeAxesYGridLines = 0
threshold1Display.CubeAxesYTitle = 'Y-Axis'
threshold1Display.CubeAxesUseDefaultYTitle = 1
threshold1Display.CubeAxesZAxisMinorTickVisibility = 1
threshold1Display.CubeAxesZAxisTickVisibility = 1
threshold1Display.CubeAxesZAxisVisibility = 1
threshold1Display.CubeAxesZGridLines = 0
threshold1Display.CubeAxesZTitle = 'Z-Axis'
threshold1Display.CubeAxesUseDefaultZTitle = 1
threshold1Display.CubeAxesGridLineLocation = 'All Faces'
threshold1Display.CustomBounds = [0.0, 1.0, 0.0, 1.0, 0.0, 1.0]
threshold1Display.CustomBoundsActive = [0, 0, 0]
threshold1Display.OriginalBoundsRangeActive = [0, 0, 0]
threshold1Display.CustomRange = [0.0, 1.0, 0.0, 1.0, 0.0, 1.0]
threshold1Display.CustomRangeActive = [0, 0, 0]
threshold1Display.UseAxesOrigin = 0
threshold1Display.AxesOrigin = [0.0, 0.0, 0.0]
threshold1Display.CubeAxesXLabelFormat = '%-#6.3g'
threshold1Display.CubeAxesYLabelFormat = '%-#6.3g'
threshold1Display.CubeAxesZLabelFormat = '%-#6.3g'
threshold1Display.StickyAxes = 0
threshold1Display.CenterStickyAxes = 0
threshold1Display.SelectionCellLabelBold = 0
threshold1Display.SelectionCellLabelColor = [0.0, 1.0, 0.0]
threshold1Display.SelectionCellLabelFontFamily = 'Arial'
threshold1Display.SelectionCellLabelFontSize = 18
threshold1Display.SelectionCellLabelItalic = 0
threshold1Display.SelectionCellLabelJustification = 'Left'
threshold1Display.SelectionCellLabelOpacity = 1.0
threshold1Display.SelectionCellLabelShadow = 0
threshold1Display.SelectionPointLabelBold = 0
threshold1Display.SelectionPointLabelColor = [0.5, 0.5, 0.5]
threshold1Display.SelectionPointLabelFontFamily = 'Arial'
threshold1Display.SelectionPointLabelFontSize = 18
threshold1Display.SelectionPointLabelItalic = 0
threshold1Display.SelectionPointLabelJustification = 'Left'
threshold1Display.SelectionPointLabelOpacity = 1.0
threshold1Display.SelectionPointLabelShadow = 0
threshold1Display.ScalarOpacityUnitDistance = 0.09821109245269406
threshold1Display.SelectMapper = 'Projected tetra'

ColorBy(threshold1Display, ('CELLS', 'icec'))

threshold1Display.RescaleTransferFunctionToDataRange(True)
threshold1Display.SetScalarBarVisibility(renderView1, True)

icecLUT = GetColorTransferFunction('icec')
icecLUT.InterpretValuesAsCategories = 0
icecLUT.EnableOpacityMapping = 0
icecLUT.RGBPoints = [0.0, 0.231373, 0.298039, 0.752941, 0.5, 0.865003, 0.865003, 0.865003, 1.0, 0.705882, 0.0156863, 0.14902]
icecLUT.UseLogScale = 0
icecLUT.LockScalarRange = 0
icecLUT.ColorSpace = 'Diverging'
icecLUT.UseBelowRangeColor = 0
icecLUT.BelowRangeColor = [0.0, 0.0, 0.0]
icecLUT.UseAboveRangeColor = 0
icecLUT.AboveRangeColor = [1.0, 1.0, 1.0]
icecLUT.NanColor = [0.5, 0.0, 0.0]
icecLUT.Discretize = 1
icecLUT.NumberOfTableValues = 256
icecLUT.ScalarRangeInitialized = 1.0
icecLUT.HSVWrap = 0
icecLUT.VectorComponent = 0
icecLUT.VectorMode = 'Magnitude'
icecLUT.AllowDuplicateScalars = 1
icecLUT.Annotations = []
icecLUT.IndexedColors = []

icecPWF = GetOpacityTransferFunction('icec')
icecPWF.Points = [0.0, 0.0, 0.5, 0.0, 1.0, 1.0, 0.5, 0.0]
icecPWF.AllowDuplicateScalars = 1
icecPWF.ScalarRangeInitialized = 1

icecLUT.RescaleTransferFunction(0.0, 1.1)
icecPWF.RescaleTransferFunction(0.0, 1.1)
icecLUT.LockScalarRange = 1

renderView1.CameraPosition = [0.0002856475883964321, -0.5844810051027729, 4.5332916091580095]
renderView1.CameraViewUp = [-0.0011829165841479169, 0.9917899270650885, 0.12787236323999585]
renderView1.CameraParallelScale = 1.7320508075688772

WriteAnimation('/Users/razoumov/Documents/03-webinar/111.png', Magnification=1, FrameRate=15.0, Compression=True)
