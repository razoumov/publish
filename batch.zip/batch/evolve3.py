from paraview.simple import *

for i in range(1968): # 1968
    print 'processing surface_'+str(i)+'.vts'
    surface_0vts = XMLStructuredGridReader(FileName=['/Users/razoumov/Movies/data/surfaceIce/surface/surface_'+str(i)+'.vts'])

    renderView1 = GetActiveViewOrCreate('RenderView')
    renderView1.ViewSize = [1246, 882]
    icecLUT = GetColorTransferFunction('icec')
    icecLUT.InterpretValuesAsCategories = 0
    icecLUT.EnableOpacityMapping = 0
    icecLUT.RGBPoints = [0.0, 0.231373, 0.298039, 0.752941, 5.e19, 0.865003, 0.865003, 0.865003, 1.e20, 0.705882, 0.0156863, 0.14902]
    icecLUT.UseLogScale = 0
    icecLUT.LockScalarRange = 0
    icecLUT.ColorSpace = 'Diverging'
    icecLUT.UseBelowRangeColor = 0
    icecLUT.BelowRangeColor = [0.0, 0.0, 0.0]
    icecLUT.UseAboveRangeColor = 0
    icecLUT.AboveRangeColor = [1.0, 1.0, 1.0]
    icecLUT.NanColor = [0.5, 0.0, 0.0]
    icecLUT.Discretize = 1
    icecLUT.NumberOfTableValues = 256
    icecLUT.ScalarRangeInitialized = 1.0
    icecLUT.HSVWrap = 0
    icecLUT.VectorComponent = 0
    icecLUT.VectorMode = 'Magnitude'
    icecLUT.AllowDuplicateScalars = 1
    icecLUT.Annotations = []
    icecLUT.IndexedColors = []
    icecPWF = GetOpacityTransferFunction('icec')
    icecPWF.Points = [0.0, 0.0, 0.5, 0.0, 1.e+20, 1.0, 0.5, 0.0]
    icecPWF.AllowDuplicateScalars = 1
    icecPWF.ScalarRangeInitialized = 1
    threshold1 = Threshold(Input=surface_0vts)
    threshold1.Scalars = ['CELLS', 'icec']
    threshold1.AllScalars = 1
    threshold1.UseContinuousCellRange = 0
    threshold1.ThresholdRange = [0.0, 100.0]
    threshold1Display = Show(threshold1, renderView1)
    threshold1Display.Representation = 'Surface'
    threshold1Display.AmbientColor = [1.0, 1.0, 1.0]
    threshold1Display.ColorArrayName = ['CELLS', 'icec']
    threshold1Display.DiffuseColor = [1.0, 1.0, 1.0]
    threshold1Display.LookupTable = icecLUT
    threshold1Display.MapScalars = 1
    threshold1Display.InterpolateScalarsBeforeMapping = 1
    threshold1Display.Opacity = 1.0
    threshold1Display.PointSize = 2.0
    threshold1Display.LineWidth = 1.0
    threshold1Display.Interpolation = 'Gouraud'
    threshold1Display.Specular = 0.0
    threshold1Display.SpecularColor = [1.0, 1.0, 1.0]
    threshold1Display.SpecularPower = 100.0
    threshold1Display.Ambient = 0.0
    threshold1Display.Diffuse = 1.0
    threshold1Display.EdgeColor = [0.0, 0.0, 0.5]
    threshold1Display.BackfaceRepresentation = 'Follow Frontface'
    threshold1Display.BackfaceAmbientColor = [1.0, 1.0, 1.0]
    threshold1Display.BackfaceDiffuseColor = [1.0, 1.0, 1.0]
    threshold1Display.BackfaceOpacity = 1.0
    threshold1Display.Position = [0.0, 0.0, 0.0]
    threshold1Display.Scale = [1.0, 1.0, 1.0]
    threshold1Display.Orientation = [0.0, 0.0, 0.0]
    threshold1Display.Origin = [0.0, 0.0, 0.0]
    threshold1Display.Pickable = 1
    threshold1Display.Texture = None
    threshold1Display.Triangulate = 0
    threshold1Display.NonlinearSubdivisionLevel = 1
    threshold1Display.CubeAxesColor = [1.0, 1.0, 1.0]
    threshold1Display.CubeAxesCornerOffset = 0.0
    threshold1Display.CubeAxesFlyMode = 'Closest Triad'
    threshold1Display.CubeAxesInertia = 1
    threshold1Display.CubeAxesTickLocation = 'Inside'
    threshold1Display.CubeAxesXAxisMinorTickVisibility = 1
    threshold1Display.CubeAxesXAxisTickVisibility = 1
    threshold1Display.CubeAxesXAxisVisibility = 1
    threshold1Display.CubeAxesXGridLines = 0
    threshold1Display.CubeAxesXTitle = 'X-Axis'
    threshold1Display.CubeAxesUseDefaultXTitle = 1
    threshold1Display.CubeAxesYAxisMinorTickVisibility = 1
    threshold1Display.CubeAxesYAxisTickVisibility = 1
    threshold1Display.CubeAxesYAxisVisibility = 1
    threshold1Display.CubeAxesYGridLines = 0
    threshold1Display.CubeAxesYTitle = 'Y-Axis'
    threshold1Display.CubeAxesUseDefaultYTitle = 1
    threshold1Display.CubeAxesZAxisMinorTickVisibility = 1
    threshold1Display.CubeAxesZAxisTickVisibility = 1
    threshold1Display.CubeAxesZAxisVisibility = 1
    threshold1Display.CubeAxesZGridLines = 0
    threshold1Display.CubeAxesZTitle = 'Z-Axis'
    threshold1Display.CubeAxesUseDefaultZTitle = 1
    threshold1Display.CubeAxesGridLineLocation = 'All Faces'
    threshold1Display.CustomBounds = [0.0, 1.0, 0.0, 1.0, 0.0, 1.0]
    threshold1Display.CustomBoundsActive = [0, 0, 0]
    threshold1Display.OriginalBoundsRangeActive = [0, 0, 0]
    threshold1Display.CustomRange = [0.0, 1.0, 0.0, 1.0, 0.0, 1.0]
    threshold1Display.CustomRangeActive = [0, 0, 0]
    threshold1Display.UseAxesOrigin = 0
    threshold1Display.AxesOrigin = [0.0, 0.0, 0.0]
    threshold1Display.CubeAxesXLabelFormat = '%-#6.3g'
    threshold1Display.CubeAxesYLabelFormat = '%-#6.3g'
    threshold1Display.CubeAxesZLabelFormat = '%-#6.3g'
    threshold1Display.StickyAxes = 0
    threshold1Display.CenterStickyAxes = 0
    threshold1Display.SelectionCellLabelBold = 0
    threshold1Display.SelectionCellLabelColor = [0.0, 1.0, 0.0]
    threshold1Display.SelectionCellLabelFontFamily = 'Arial'
    threshold1Display.SelectionCellLabelFontSize = 18
    threshold1Display.SelectionCellLabelItalic = 0
    threshold1Display.SelectionCellLabelJustification = 'Left'
    threshold1Display.SelectionCellLabelOpacity = 1.0
    threshold1Display.SelectionCellLabelShadow = 0
    threshold1Display.SelectionPointLabelBold = 0
    threshold1Display.SelectionPointLabelColor = [0.5, 0.5, 0.5]
    threshold1Display.SelectionPointLabelFontFamily = 'Arial'
    threshold1Display.SelectionPointLabelFontSize = 18
    threshold1Display.SelectionPointLabelItalic = 0
    threshold1Display.SelectionPointLabelJustification = 'Left'
    threshold1Display.SelectionPointLabelOpacity = 1.0
    threshold1Display.SelectionPointLabelShadow = 0
    threshold1Display.ScalarOpacityUnitDistance = 0.09821109245269406
    threshold1Display.SelectMapper = 'Projected tetra'
    threshold1Display.SetScalarBarVisibility(renderView1, True)
    icecLUT.LockScalarRange = 1
    icecLUT.RescaleTransferFunction(0.0, 1.0) # colour map
    icecPWF.RescaleTransferFunction(0.0, 1.0) # opacity map
    renderView1.CameraPosition = [-0.8326040226834823, -2.469711420796504, 4.878092562826748]
    renderView1.CameraViewUp = [0.018123688407467635, 0.8907760119470987, 0.4540810813699811]
    renderView1.CameraParallelScale = 1.7320508075688772

    SaveScreenshot('/Users/razoumov/Documents/03-webinar/frame%04d'%(i)+'.png', magnification=1, quality=100, view=renderView1)

    Delete(threshold1)
    Delete(surface_0vts)
