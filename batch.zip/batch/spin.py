from paraview.simple import *
sineEnvelopenc = NetCDFReader(FileName=['/Users/razoumov/Documents/03-webinar/sineEnvelope.nc'])

renderView1 = GetActiveViewOrCreate('RenderView')
sineEnvelopencDisplay = Show(sineEnvelopenc, renderView1)
sineEnvelopencDisplay.SetRepresentationType('Volume')
ColorBy(sineEnvelopencDisplay, ('POINTS', 'f(x,y,z)'))
sineEnvelopencDisplay.RescaleTransferFunctionToDataRange(True)

# select the "Red to Blue Rainbow" colour map
fxyzLUT = GetColorTransferFunction('fxyz')
fxyzLUT.InterpretValuesAsCategories = 0
fxyzLUT.EnableOpacityMapping = 0
fxyzLUT.RGBPoints = [0.01945, 1.0, 0.0, 0.0, 1.99497, 0.0, 0.0, 1.0]
fxyzLUT.UseLogScale = 0
fxyzLUT.LockScalarRange = 0
fxyzLUT.ColorSpace = 'HSV'
fxyzLUT.UseBelowRangeColor = 0
fxyzLUT.BelowRangeColor = [0.0, 0.0, 0.0]
fxyzLUT.UseAboveRangeColor = 0
fxyzLUT.AboveRangeColor = [1.0, 1.0, 1.0]
fxyzLUT.NanColor = [0.498039, 0.498039, 0.498039]
fxyzLUT.Discretize = 1
fxyzLUT.NumberOfTableValues = 256
fxyzLUT.ScalarRangeInitialized = 1.0
fxyzLUT.HSVWrap = 0
fxyzLUT.VectorComponent = 0
fxyzLUT.VectorMode = 'Magnitude'
fxyzLUT.AllowDuplicateScalars = 1

# edit the points on the colour map
fxyzPWF = GetOpacityTransferFunction('fxyz')
fxyzPWF.Points = [0.019445, 0.0, 0.5, 0.0, 1.53422, 0.0, 0.5, 0.0, 1.99497, 0.55625, 0.5, 0.0]

# set camera position
renderView1.CameraPosition = [36.9412, 156.4122, 362.7818]
renderView1.CameraFocalPoint = [49.5, 49.5, 49.5]
renderView1.CameraViewUp = [0.0046171, 0.946453, -0.3228]
renderView1.CameraParallelScale = 85.7365

SaveScreenshot('/Users/razoumov/Documents/03-webinar/test.png', magnification=2, quality=100, view=renderView1)
