# this is orange.py
DeleteAllPlots()
AddPlot("Pseudocolor", "hardyglobal")
p = PseudocolorAttributes()
p.colorTableName = "Oranges"
SetPlotOptions(p)
DrawPlots()
