# this is threeSurfaces.py
isoAtts.contourMethod = isoAtts.Value  # contour by value(s)
for i in range(3):
    isoAtts.contourValue = 2. + i*1.5
    SetOperatorOptions(isoAtts)
