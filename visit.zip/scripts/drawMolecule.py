# this is drawMolecule.py
OpenDatabase("~/teaching/visitWorkshop/datasets/molecules/1l5q.pdb", 0)
AddPlot("Molecule", "element", 1, 1)
DrawPlots()

m = MoleculeAttributes()

m.drawAtomsAs = m.SphereAtoms # NoAtoms, SphereAtoms, ImposterAtoms
m.scaleRadiusBy = m.Fixed  # Fixed, Covalent, Atomic, Variable
m.atomSphereQuality = m.Medium  # Low, Medium, High, Super
m.radiusFixed = 0.5

m.drawBondsAs = m.CylinderBonds # NoBonds, LineBonds, CylinderBonds
m.colorBonds = m.ColorByAtom  # ColorByAtom, SingleColor
m.bondCylinderQuality = m.Medium  # Low, Medium, High, Super
m.bondRadius = 0.08

m.elementColorTable = "cpk_jmol"
m.legendFlag = 1
SetPlotOptions(m)
