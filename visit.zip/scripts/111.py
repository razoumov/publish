for i in range(10):
    print i
    print i**2

print 'the end'
