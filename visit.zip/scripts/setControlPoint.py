# this is setControlPoint.py
from math import *
c0 = View3DAttributes()
phi = 0   # 0 <= phi <= 2*pi
theta = 0   # -pi/2 <= theta <= pi/2
c0.viewNormal = (cos(theta)*cos(phi),cos(theta)*sin(phi),sin(theta))
c0.focus, c0.viewUp = (0, 0, 0), (0, 0, 1)
c0.viewAngle, c0.parallelScale, c0.imageZoom = 30, 17.3205, 1
c0.nearPlane, c0.farPlane, c0.perspective = -34.641, 34.641, 1
SetView3D(c0)
