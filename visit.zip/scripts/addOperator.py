# this is addOperator.py
DeleteAllPlots()
AddPlot("Pseudocolor", "hardyglobal")
AddOperator("Isosurface")
isoAtts = IsosurfaceAttributes() # create an operator attributes object
isoAtts.contourMethod = isoAtts.Level  # contour by level(s)
isoAtts.variable = "hardyglobal"
SetOperatorOptions(isoAtts) # set operator attributes to above values
DrawPlots()
print isoAtts   # default is 10 isosurface levels
