# this is terrain3d.py
DeleteAllPlots()
OpenDatabase("~/teaching/visitWorkshop/datasets/092g06.dem")
AddPlot("Pseudocolor", "height")

AddOperator("Elevate")
e = ElevateAttributes()
e.useXYLimits = 1 # if X/Y are longitude/latitude, z-height would be off
SetOperatorOptions(e) #   => simply rescale all 3 axes to a cube

AddOperator("Transform")
t = TransformAttributes()
t.doScale = 1     # turn on scaling
t.scaleX, t.scaleY, t.scaleZ = 1, 1, 0.05   # and make z-heights smaller
SetOperatorOptions(t)

DrawPlots()
