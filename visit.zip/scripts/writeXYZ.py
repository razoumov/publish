from random import random, randint
from math import sin, cos, asin, pi
elements = 'HNCO'
natoms = int(1e6)
print(natoms)
print('some comment')
n = len(elements) - 1
for i in range(natoms):
    theta = asin(2.*random()-1.)
    phi = 2.*pi*random()
    x = 0.5 + 0.5*cos(theta)*cos(phi)
    y = 0.5 + 0.5*cos(theta)*sin(phi)
    z = 0.5 + 0.5*sin(theta)
    print(elements[randint(0,n)], x, y, z)
