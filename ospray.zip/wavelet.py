from paraview.simple import *

wavelet1 = Wavelet()
renderView1 = GetActiveViewOrCreate('RenderView')
renderView1.ViewSize = [1280, 720]

shrink1 = Shrink(Input=wavelet1)
rTDataLUT = GetColorTransferFunction('RTData')

Hide(wavelet1, renderView1)
Hide(shrink1, renderView1)

glyph1 = Glyph(Input=shrink1, GlyphType='Sphere')
glyph1.Scalars = ['POINTS', 'RTData']
glyph1.Vectors = ['POINTS', 'None']
glyph1.ScaleFactor = 1.95
glyph1.GlyphType.Radius = 0.2
glyph1.GlyphType.ThetaResolution = 30
glyph1.GlyphType.PhiResolution = 30

glyph1Display = Show(glyph1, renderView1)
glyph1Display.ColorArrayName = ['POINTS', 'RTData']
glyph1Display.LookupTable = rTDataLUT
glyph1Display.GlyphType = 'Arrow'
glyph1Display.SetScaleArray = ['POINTS', 'RTData']
glyph1Display.ScaleTransferFunction = 'PiecewiseFunction'
glyph1Display.OpacityArray = ['POINTS', 'RTData']
glyph1Display.OpacityTransferFunction = 'PiecewiseFunction'

renderView1.CameraPosition = [-40.57242525131943, 20.7869159629548, 43.073450283532516]
renderView1.CameraFocalPoint = [0.3880089693718842, -1.4969286758104854, 1.1754828437649194]
renderView1.CameraViewUp = [0.2571900240728232, 0.9264876350141374, -0.27472523306629704]
renderView1.CameraParallelScale = 17.3205080757

# renderView1.EnableOSPRay = 1
# renderView1.Shadows = 1
# renderView1.SamplesPerPixel = 1

import time
camera = GetActiveCamera()
numberOfFrames = 270
t1 = time.time()
for i in range(numberOfFrames):
    print i
    camera.Azimuth(.333)
    SaveScreenshot('/Users/razoumov/Documents/ospray/frame%04d'%i+'.png',
                   magnification=1, quality=100, view=renderView1)
t2 = time.time()
print t2-t1, 'seconds elapsed'
print float(numberOfFrames)/float(t2-t1), 'fps'
