def readLongestParagraphs(filename, numberParagraphs=None):
    """
    Put numberParagraphs longest paragraphs from a file into a list.
    Each paragraph will be a separate element in this list.
    If numberParagraphs is missing, all paragraphs from the file will be used.
    """
    
    f = open(filename, 'r')
    data = f.read()

    # split text into paragraphs
    paragraphs = data.split("\n\n")

    # pick numberParagraphs longest paragraphs for analysis
    longest = sorted(paragraphs, key=len, reverse=True)
    return longest[0:numberParagraphs]
