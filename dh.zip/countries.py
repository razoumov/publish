import pandas as pd
from writeNodesEdges import writeObjects

data = pd.read_csv('legatum2015.csv', sep=',')

economy = list(data['economy'])
entrepreneurshipOpportunity = list(data['entrepreneurshipOpportunity'])
governance = list(data['governance'])
xyz = [[i,j,k] for i,j,k in zip(economy,entrepreneurshipOpportunity,governance)]

writeObjects(xyz, fileout='countries', nodeLabel = list(data['country']),
             scalar = list(data['education']), name = 'education',
             scalar2 = list(data['safetySecurity']+6), name2 = 'safetySecurity', power2 = 1)
