import string
from gensim import corpora, models, similarities
from collections import defaultdict
from scipy.spatial import distance
import sys
import numpy as np
from sklearn import manifold
from writeNodesEdges import writeObjects
from humanities import readLongestParagraphs

# The Time Machine, by Herbert Wells
documents = readLongestParagraphs('pg35.txt',30)

# Oliver Twist, by Charles Dickens
documents += readLongestParagraphs('pg730.txt',30)

# Adventures of Huckleberry Finn, by Mark Twain
documents += readLongestParagraphs('pg76.txt',30)

# The War of the Worlds, by Herbert Wells
documents += readLongestParagraphs('pg36.txt',30)

# Galiliean-invariant cosmological hydrodynamical simulations on a moving mesh, by Volker Springel
documents += readLongestParagraphs('springel09.txt',30)

# convert line breaks and dashes to spaces, and remove punctuation
for i, p in enumerate(documents):
    tmp = p.replace('\n', ' ').replace('-',' ')
    for c in string.punctuation:
        tmp = tmp.replace(c,'')
    documents[i] = tmp

# remove common words and tokenize (break into words)
stoplist = set('for from a of the and to in at through'.split())
texts = [[word for word in document.lower().split() if word not in stoplist] for document in documents]

# count words across all paragraphs
frequency = defaultdict(int)
for text in texts:
    for token in text:
        frequency[token] += 1

# remove words that appear only once across all paragraphs
texts = [[token for token in text if frequency[token] > 1] for text in texts]

# build a dictionary of words from scratch (not related to above word count)
dictionary = corpora.Dictionary(texts)
# print dictionary.token2id # print IDs of all words in the dictionary
nwords = len(dictionary.token2id)
print 'built a global dictionary with', nwords, 'words'

# convert documents to sparse vectors containing tuples (wordID, wordCount)
corpus = [dictionary.doc2bow(text) for text in texts]

# convert sparse vectors to full vectors of length nwords
fullCorpus = []
for d in corpus:
    fullVector = [0]*nwords
    for word in d:
        id, count = word
        fullVector[id] = count
    fullCorpus.append(fullVector)

# normalize each full vector
normalizedFullCorpus = []
for d in fullCorpus:
    numberWordsInsideDocument = sum(d)
    normalizedCount = [float(word)/float(numberWordsInsideDocument) for word in d]
    normalizedFullCorpus.append(normalizedCount)

# compute distance from d1 to d2 in nwords-dimensional space
dist = []
for i, d1 in enumerate(normalizedFullCorpus):
    row = []
    for j, d2 in enumerate(normalizedFullCorpus):
        if i < j:
            row.append(distance.euclidean(d1,d2))
        else:
            row.append(0)
    dist.append(row)

n = len(dist)
distArray = np.array(dist)
for i in range(n):
    for j in range(n):
        if i > j:
            distArray[i,j] = distArray[j,i]

amax = np.amax(distArray)
distArray /= amax

mds = manifold.MDS(n_components=3, dissimilarity="precomputed", random_state=6) # multidimensional scaling
results = mds.fit(distArray)
coords = results.embedding_
print coords

author = [1]*30 + [2]*30 + [3]*30 + [1]*30 + [4]*30
novelPerAuthor = [2]*30 + [2]*30 + [2]*30 + [1]*30 + [2]*30
writeObjects(coords, scalar=author, name='author', fileout='texts',
             scalar2=novelPerAuthor, name2='novel per author', method = 'vtkUnstructuredGrid')
