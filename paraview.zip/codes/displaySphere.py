from paraview.simple import *

sphere = Sphere()               # create a sphere pipeline object
print(sphere.ThetaResolution)   # print one of the attributes of the sphere
sphere.ThetaResolution = 16

Show()                          # make it visible in the view
Render()
