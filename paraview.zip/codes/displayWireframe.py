from paraview.simple import *

sphere = Sphere(ThetaResolution=36, PhiResolution=18)

wireframe = ExtractEdges(Input=sphere)   # apply Extract Edges to sphere

Show()   # make the last object visible in the view
Render()
