import numpy as np
from netCDF4 import Dataset

nx = 100
ny, nz = nx, nx

x = (np.arange(nx) + 0.5) / nx
y = (np.arange(ny) + 0.5) / ny
z = (np.arange(nz) + 0.5) / nz

X, Y, Z = np.meshgrid(x, y, z, indexing='ij')
r = np.sqrt((X - 0.5)**2 + (Y - 0.5)**2)
density = np.exp(-np.sqrt((Z - 0.5)**2 + (r - 0.4)**2))

with Dataset("volume.nc", "w", format="NETCDF4") as rootgrp:
    rootgrp.createDimension("x", nx)
    rootgrp.createDimension("y", ny)
    rootgrp.createDimension("z", nz)
    density_var = rootgrp.createVariable("density", "f4", ("x", "y", "z"))
    density_var[:] = density
