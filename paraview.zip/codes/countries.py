import pandas as pd
from writeNodesEdges import writeObjects
data = pd.read_csv('legatum2015.csv', sep=',')

>>> (fill in this part) <<<

writeObjects(xyz, fileout='countries',
             nodeLabel = list(data['country']),
             scalar = list(data['education']),
             name = 'education',
             scalar2 = list(data['safetySecurity']+6),
             name2 = 'safetySecurity', power2 = 1)
