# codes/extractValues.py
from paraview.simple import *

dir = "/Users/razoumov/training/paraviewWorkshop/data/"   # edit the path
data = NetCDFReader(FileName=[dir+"sineEnvelope.nc"])
print(type(data))                 # class paraview.servermanager.NetCDFReader

local = servermanager.Fetch(data) # get this data from the server
print(local.GetNumberOfPoints())
print(local.GetDimensions())

# the following are populated with data only after servermanager.Fetch(data) is called
pointInfo = data.GetDataInformation().GetPointDataInformation()
narrays = pointInfo.GetNumberOfArrays()
print(narrays)

for i in range(narrays):
    print(pointInfo.GetArrayInformation(i).GetName())

for i in range(10):
    print(local.GetPoint(i))      # coordinates of the first 10 points

vtkArray = local.GetPointData().GetArray("density")
print(vtkArray.GetDataSize(), vtkArray.GetRange())

for i in range(10):
    print(vtkArray.GetValue(i)) # values at first 10 points: awkward to use

from vtk.numpy_interface import dataset_adapter as dsa

wrapped = dsa.WrapDataObject(local)   # wrap it in a NumPy-friendly object
flatArray = wrapped.PointData["density"]
print(flatArray.shape)
print(flatArray)

import numpy as np

dims = local.GetDimensions()
array3d = np.reshape(flatArray, (dims[2], dims[1], dims[0]))
print(array3d.shape)
print(array3d)
