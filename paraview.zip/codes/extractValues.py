# codes/extractValues.py
from paraview.simple import *

dir = '/Users/razoumov/training/paraviewWorkshop/data/'
data = NetCDFReader(FileName=[dir+'stvol.nc'])
local = servermanager.Fetch(data) # get the data from the server
print(local.GetNumberOfPoints())

for i in range(10):
    print(local.GetPoint(i))   # coordinates of first 10 points

pd = local.GetPointData()
print(pd.GetArrayName(0))   # the name of the first array

result = pd.GetArray('f(x,y,z)')
print(result.GetDataSize(), result.GetRange())

for i in range(10):
    print(result.GetValue(i))   # values at first 10 points
